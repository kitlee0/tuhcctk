package WebNoiThat.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import WebNoiThat.model.Khach_HangRepository;

@Controller
public class Khach_HangController {
	@Autowired
	Khach_HangRepository khach_hangRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@GetMapping("/admin/khach_hang")
	public String index(Model model) {
		model.addAttribute("list", khach_hangRepository.findAll());
		return ("khach_hang/index");
	}

	@GetMapping("/khach_hang/add")
	public String add() {
		return "khach_hang/add";
	}

	@PostMapping("/khach_hang/add")
	public String add(WebNoiThat.model.Khach_Hang obj) {
		obj.setPassword(passwordEncoder.encode(obj.getPassword()));
		khach_hangRepository.save(obj);
		return "redirect:/khach_hang";
	}

	@GetMapping("/khach_hang/edit/{makhachhang}")
	public String edit(@PathVariable("makhachhang") short makhachhang, Model model) {
		model.addAttribute("o", khach_hangRepository.findById(makhachhang).get());
		return "khach_hang/edit";
	}

	@PostMapping("/khach_hang/edit/{makhachhang}")
	public String edit(@PathVariable("makhachhang") short makhachhang, WebNoiThat.model.Khach_Hang obj) {
		obj.setMakhachhang(makhachhang);
		khach_hangRepository.save(obj);
		return "redirect:/khach_hang";
	}

	@GetMapping("/khach_hang/delete/{makhachhang}")
	public String delete(@PathVariable("makhachhang") short makhachhang) {
		khach_hangRepository.deleteById(makhachhang);
		return "redirect:/khach_hang";
	}
}
