package WebNoiThat.model;

import org.springframework.data.repository.CrudRepository;

public interface San_PhamRepository extends CrudRepository<San_Pham, Short>{}
