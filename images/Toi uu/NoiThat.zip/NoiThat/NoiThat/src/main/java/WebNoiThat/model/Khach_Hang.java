package WebNoiThat.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;

@Entity(name = "khach_hang")
public class Khach_Hang {

	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	@Column(name = "ma_khach_hang")
	private short makhachhang;
	@Column(name = "ten_khach_hang")
	private String tenkhachhang;
	@Column(name = "password")
	private String password;

	@Enumerated(EnumType.STRING)
	@Column(name = "role", nullable = true)
	private Role role;

	@Column(name = "email")
	private String email;
	@Column(name = "so_dien_thoai")
	private String sodienthoai;

	public Khach_Hang() {

	}

	public Khach_Hang(String tenkhachhang, String password, Role role) {
		this.tenkhachhang = tenkhachhang;
		this.password = password;
		this.role = role;
	}

	public short getMakhachhang() {
		return makhachhang;
	}

	public void setMakhachhang(short makhachhang) {
		this.makhachhang = makhachhang;
	}

	public String getTenkhachhang() {
		return tenkhachhang;
	}

	public void setTenkhachhang(String tenkhachhang) {
		this.tenkhachhang = tenkhachhang;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSodienthoai() {
		return sodienthoai;
	}

	public void setSodienthoai(String sodienthoai) {
		this.sodienthoai = sodienthoai;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Role getRole() {
		return role;
	}

	@PrePersist
	public void setRole() {
		if (this.role == null) {
			this.role = Role.USER;
		}
	}

}