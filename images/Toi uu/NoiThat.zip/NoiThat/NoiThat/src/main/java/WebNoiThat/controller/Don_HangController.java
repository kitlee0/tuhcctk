package WebNoiThat.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import WebNoiThat.model.Don_HangRepository;
//import org.springframework.web.bind.annotation.PostMapping;
//import WebNoiThat.model.San_Pham;
//import WebNoiThat.model.San_PhamRepository;

@Controller
public class Don_HangController {
	@Autowired
	Don_HangRepository don_hangRepository;

	@GetMapping("/admin/don_hang")
	public String index(Model model) {
		model.addAttribute("list", don_hangRepository.findAll());
		return ("don_hang/index");
	}

	@GetMapping("/don_hang/add")
	public String add() {
		return "don_hang/add";
	}

	@PostMapping("/don_hang/add")
	public String add(WebNoiThat.model.Don_Hang obj) {
		don_hangRepository.save(obj);
		return "redirect:/don_hang";
	}

	@GetMapping("/don_hang/edit/{madonhang}")
	public String edit(@PathVariable("madonhang") short madonhang, Model model) {
		model.addAttribute("o", don_hangRepository.findById(madonhang).get());
		return "don_hang/edit";
	}

	@PostMapping("/don_hang/edit/{madonhang}")
	public String edit(@PathVariable("madonhang") short madonhang, WebNoiThat.model.Don_Hang obj) {
		obj.setMadonhang(madonhang);
		don_hangRepository.save(obj);
		return "redirect:/don_hang";
	}

	@GetMapping("/don_hang/delete/{madonhang}")
	public String delete(@PathVariable("madonhang") short madonhang) {
		don_hangRepository.deleteById(madonhang);
		return "redirect:/don_hang";
	}
}
