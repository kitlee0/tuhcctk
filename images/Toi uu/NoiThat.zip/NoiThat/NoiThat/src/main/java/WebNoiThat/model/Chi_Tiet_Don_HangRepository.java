package WebNoiThat.model;

import org.springframework.data.repository.CrudRepository;

public interface Chi_Tiet_Don_HangRepository extends CrudRepository<Chi_Tiet_Don_Hang, Short> {
}
