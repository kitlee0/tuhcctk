package WebNoiThat.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity(name = "chi_tiet_don_hang")
public class Chi_Tiet_Don_Hang {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "ma_chi_tiet")
    private short machitiet;
    @Column(name = "ma_don_hang")
    private String madonhang;
    @Column(name = "ma_san_pham")
    private String masanpham;
    @Column(name = "so_luong")
    private int soluong;
    @Column(name = "gia")
    private int gia;
    @Column(name = "tong_tien", insertable = false, updatable = false)
    private int tongtien;

    public short getMachitiet() {
        return machitiet;
    }

    public void setMachitiet(short machitiet) {
        this.machitiet = machitiet;
    }

    public String getMadonhang() {
        return madonhang;
    }

    public void setMadonhang(String madonhang) {
        this.madonhang = madonhang;
    }

    public String getMasanpham() {
        return masanpham;
    }

    public void setMasanpham(String masanpham) {
        this.masanpham = masanpham;
    }

    public int getSoluong() {
        return soluong;
    }

    public void setSoluong(int soluong) {
        this.soluong = soluong;
    }

    public int getGia() {
        return gia;
    }

    public void setGia(int gia) {
        this.gia = gia;
    }

    public int getTongtien() {
        return tongtien;
    }

    public void setTongtien(int tongtien) {
        this.tongtien = tongtien;
    }

}