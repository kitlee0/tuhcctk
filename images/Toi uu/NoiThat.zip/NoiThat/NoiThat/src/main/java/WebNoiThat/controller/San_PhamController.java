package WebNoiThat.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import WebNoiThat.model.San_PhamRepository;
import WebNoiThat.service.SanPhamService;

@Controller
public class San_PhamController {
	@Autowired
	San_PhamRepository san_phamRepository;
	@Autowired
	private SanPhamService sanPhamService;

	@GetMapping("/admin/san_pham")
	public String index(Model model) {
		model.addAttribute("list", san_phamRepository.findAll());
		return ("san_pham/index");
	}

	@GetMapping("/san_pham/add")
	public String add() {
		return "san_pham/add";
	}

	@PostMapping("/san_pham/add")
	public String add(WebNoiThat.model.San_Pham obj) {
		sanPhamService.updateImage(obj);
		san_phamRepository.save(obj);
		return "redirect:/san_pham";
	}

	@GetMapping("/san_pham/edit/{masanpham}")
	public String edit(@PathVariable("masanpham") short masanpham, Model model) {
		model.addAttribute("o", san_phamRepository.findById(masanpham).get());
		return "san_pham/edit";
	}

	@PostMapping("/san_pham/edit/{masanpham}")
	public String edit(@PathVariable("masanpham") short masanpham, WebNoiThat.model.San_Pham obj) {
		sanPhamService.updateImage(obj);
		obj.setMasanpham(masanpham);
		san_phamRepository.save(obj);
		return "redirect:/san_pham";
	}

	@GetMapping("/san_pham/detail/{masanpham}")
	public String detail(@PathVariable("masanpham") short masanpham, Model model) {
		model.addAttribute("o", san_phamRepository.findById(masanpham).get());
		return "san_pham/detail";
	}
	@GetMapping("/san_pham/delete/{masanpham}")
	public String delete(@PathVariable("masanpham") short masanpham) {
		san_phamRepository.deleteById(masanpham);
		return "redirect:/san_pham";
	}
}
