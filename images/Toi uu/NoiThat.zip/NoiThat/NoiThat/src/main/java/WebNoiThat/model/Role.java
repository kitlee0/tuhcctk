package WebNoiThat.model;

public enum Role {
    USER,
    ADMIN
}
