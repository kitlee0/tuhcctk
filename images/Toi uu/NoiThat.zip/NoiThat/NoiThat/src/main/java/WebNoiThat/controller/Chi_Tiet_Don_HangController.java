package WebNoiThat.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import WebNoiThat.model.Chi_Tiet_Don_HangRepository;

@Controller
public class Chi_Tiet_Don_HangController {
	@Autowired
	Chi_Tiet_Don_HangRepository chi_tiet_don_hangRepository;

	@GetMapping("/admin/chi_tiet_don_hang")
	public String index(Model model) {
		model.addAttribute("list", chi_tiet_don_hangRepository.findAll());
		return ("chi_tiet_don_hang/index");
	}

	@GetMapping("/chi_tiet_don_hang/add")
	public String add() {
		return "chi_tiet_don_hang/add";
	}

	@PostMapping("/chi_tiet_don_hang/add")
	public String add(WebNoiThat.model.Chi_Tiet_Don_Hang obj) {
		chi_tiet_don_hangRepository.save(obj);
		return "redirect:/chi_tiet_don_hang";
	}

	@GetMapping("/chi_tiet_don_hang/edit/{machitiet}")
	public String edit(@PathVariable("machitiet") short machitiet, Model model) {
		model.addAttribute("o", chi_tiet_don_hangRepository.findById(machitiet).get());
		return "chi_tiet_don_hang/edit";
	}

	@PostMapping("/chi_tiet_don_hang/edit/{machitiet}")
	public String edit(@PathVariable("machitiet") short machitiet, WebNoiThat.model.Chi_Tiet_Don_Hang obj) {
		obj.setMachitiet(machitiet);
		chi_tiet_don_hangRepository.save(obj);
		return "redirect:/chi_tiet_don_hang";
	}

	@GetMapping("/chi_tiet_don_hang/delete/{machitiet}")
	public String delete(@PathVariable("machitiet") short machitiet) {
		chi_tiet_don_hangRepository.deleteById(machitiet);
		return "redirect:/chi_tiet_don_hang";
	}
}
