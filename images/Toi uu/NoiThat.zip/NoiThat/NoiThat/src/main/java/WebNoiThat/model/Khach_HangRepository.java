package WebNoiThat.model;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

public interface Khach_HangRepository extends CrudRepository<Khach_Hang, Short> {
    Optional<Khach_Hang> findByTenkhachhang(String tenkhachhang);
}
