package WebNoiThat.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import WebNoiThat.model.Khach_HangRepository;
import WebNoiThat.model.San_PhamRepository;

@Controller
public class HomeController {
    @Autowired
    San_PhamRepository san_PhamRepository;

    @Autowired
    Khach_HangRepository khach_HangRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("list", san_PhamRepository.findAll());
        return "home/index";
    }

    @GetMapping("/login")
    public String login() {
        return "home/login";
    }

    @GetMapping("/register")
    public String register() {
        return "home/register";
    }

    @GetMapping("/admin")
    public String admin() {
        return "admin/index";
    }

    @PostMapping("/register")
    public String add(WebNoiThat.model.Khach_Hang obj) {
        if (obj.getPassword() == null) {
            System.out.println("Password is null!");
            return "home/register";
        }
        obj.setPassword(passwordEncoder.encode(obj.getPassword()));
        khach_HangRepository.save(obj);
        return "redirect:/login";
    }

    @GetMapping("/user/home")
    public String handleUserHome(Model model) {
        model.addAttribute("list", san_PhamRepository.findAll());
        return "home/index";
    }

    @GetMapping("/admin/home")
    public String handleAdminHome(Model model) {
        model.addAttribute("list", san_PhamRepository.findAll());
        return "home/index";
    }
}
