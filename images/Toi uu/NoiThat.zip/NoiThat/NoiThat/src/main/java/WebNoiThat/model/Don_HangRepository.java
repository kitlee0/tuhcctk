package WebNoiThat.model;

import org.springframework.data.repository.CrudRepository;

public interface Don_HangRepository extends CrudRepository<Don_Hang, Short> {
}
