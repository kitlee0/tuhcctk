package WebNoiThat.model;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity(name = "don_hang")
public class Don_Hang {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "ma_don_hang")
    private short madonhang;
    @Column(name = "ma_khach_hang")
    private String makhachhang;

    @ManyToOne
    @JoinColumn(name = "ma_san_pham")
    private San_Pham sanpham;

    @Column(name = "ngay_dat", nullable = true)
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date ngaydat;
    @Column(name = "trang_thai")
    private String trangthai;

    public short getMadonhang() {
        return madonhang;
    }

    public void setMadonhang(short madonhang) {
        this.madonhang = madonhang;
    }

    public String getMakhachhang() {
        return makhachhang;
    }

    public void setMakhachhang(String makhachhang) {
        this.makhachhang = makhachhang;
    }

    public String getTrangthai() {
        return trangthai;
    }

    public void setTrangthai(String trangthai) {
        this.trangthai = trangthai;
    }

    public Date getNgaydat() {
        return ngaydat;
    }

    public void setNgaydat(Date ngaydat) {
        this.ngaydat = ngaydat;
    }

    public San_Pham getSanpham() {
        return sanpham;
    }

    public void setSanpham(San_Pham sanpham) {
        this.sanpham = sanpham;
    }

}
