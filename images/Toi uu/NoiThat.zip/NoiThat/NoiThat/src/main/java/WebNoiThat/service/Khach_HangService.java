package WebNoiThat.service;

import java.util.Optional;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import WebNoiThat.model.Khach_Hang;
import WebNoiThat.model.Khach_HangRepository;

@Service
public class Khach_HangService implements UserDetailsService {
    private final Khach_HangRepository khach_HangRepository;

    public Khach_HangService(Khach_HangRepository khach_HangRepository) {
        this.khach_HangRepository = khach_HangRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String tenkhachhang) throws UsernameNotFoundException {
        Optional<Khach_Hang> khach_Hang = khach_HangRepository.findByTenkhachhang(tenkhachhang);
        if (khach_Hang.isPresent()) {
            var userObj = khach_Hang.get();
            return User.builder()
                    .username(userObj.getTenkhachhang())
                    .password(userObj.getPassword())
                    .roles(getRoles(userObj))
                    .build();
        } else {
            throw new UsernameNotFoundException(tenkhachhang);
        }
    }

    private String[] getRoles(Khach_Hang khach_Hang) {
        if (khach_Hang.getRole() == null) {
            return new String[] { "USER" };
        }

        return khach_Hang.getRole().name().replace("ROLE_", "").split(",");
    }

}
