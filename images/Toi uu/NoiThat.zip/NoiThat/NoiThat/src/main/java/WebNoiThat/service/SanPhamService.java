package WebNoiThat.service;

import java.util.Base64;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import WebNoiThat.model.San_Pham;
import WebNoiThat.model.San_PhamRepository;

@Service
public class SanPhamService {
    @Autowired
    private San_PhamRepository san_PhamRepository;

    public void updateImage(San_Pham sanPham) {
        if (sanPham.getImageFile() != null && !sanPham.getImageFile().isEmpty()) {
            @SuppressWarnings("null")
            String fileName = StringUtils.cleanPath(sanPham.getImageFile().getOriginalFilename());
            if (fileName.contains("..")) {
                System.out.println("Lỗi không thể lưu file");
            }
            try {
                sanPham.setImage_url(Base64.getEncoder().encodeToString(sanPham.getImageFile().getBytes()));
            } catch (Exception e) {
                e.printStackTrace();
            }

        } else {
            San_Pham existingCourse = san_PhamRepository.findById(sanPham.getMasanpham()).orElse(null);
            if (existingCourse != null) {
                sanPham.setImage_url(existingCourse.getImage_url());
            }
        }
        san_PhamRepository.save(sanPham);
    }
}
