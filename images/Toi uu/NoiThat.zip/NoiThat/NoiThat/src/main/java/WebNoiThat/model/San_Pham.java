package WebNoiThat.model;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Transient;

@Entity(name = "san_pham")
public class San_Pham {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "ma_san_pham")
    private short masanpham;
    @Column(name = "ten_san_pham")
    private String tensanpham;
    @OneToMany(mappedBy = "sanpham")
    private List<Don_Hang> donhang;
    @Column(name = "mo_ta")
    private String mota;
    @Column(name = "gia")
    private String gia;
    @Transient
    private MultipartFile imageFile;
    @Column(name = "image_url")
    private String image_url;

    public MultipartFile getImageFile() {
        return imageFile;
    }

    public void setImageFile(MultipartFile imageFile) {
        this.imageFile = imageFile;
    }

    public String getImage_url() {
        return image_url;
    }

    public void setImage_url(String image_url) {
        this.image_url = image_url;
    }

    public short getMasanpham() {
        return masanpham;
    }

    public void setMasanpham(short masanpham) {
        this.masanpham = masanpham;
    }

    public String getTensanpham() {
        return tensanpham;
    }

    public void setTensanpham(String tensanpham) {
        this.tensanpham = tensanpham;
    }

    public String getMota() {
        return mota;
    }

    public void setMota(String mota) {
        this.mota = mota;
    }

    public String getGia() {
        return gia;
    }

    public void setGia(String gia) {
        this.gia = gia;
    }

    public List<Don_Hang> getDonhang() {
        return donhang;
    }

    public void setDonhang(List<Don_Hang> donhang) {
        this.donhang = donhang;
    }

}
